Tangkapan Layar Elements
![alt text](Element.png)

Tangkapan Layar Console
![alt text](console.png)

Tangkapan layar 200
![alt text](<Network 200.png>)
Tangkapan Layar
![alt text](<Network 400.png>)

Laporan Debugging
Debugging adalah proses untuk mencari, menemukan, dan memperbaiki kesalahan atau bug dalam sebuah program. Debugging dilakukan agar program dapat berjalan dengan benar sesuai dengan yang diharapkan. Biasanya, program ini meliputi pemeriksaan kode, menemukan penyebab kesalahan, memperbaiki kode, lalu menjalankan program kembali untuk memastikan masalah sudah terselesaikan dengan baik
Gejala: CSS tidak aktif
Bukti: css/style1.css
Penyebab: Penamaan salah
Perbaikan: Memnyesuaikan penamaannya
Hasil: 200

Struktur Folder
![alt text](<struktur folder.png>)

git status
![alt text](<Git Status.png>)
git version
![alt text](<tangkapan layar git version.png>)

Minimal 2 comit
Komit 1
![alt text](<komit 1.png>)
![alt text](<komit 1.1.png>)

komit 2
![alt text](<Komit 2.png>)
